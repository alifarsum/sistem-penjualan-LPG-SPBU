-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 21 Jun 2023 pada 00.47
-- Versi server: 10.5.19-MariaDB-cll-lve
-- Versi PHP: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foewbbzh_spbu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `Admin`
--

CREATE TABLE `Admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `Barang`
--

CREATE TABLE `Barang` (
  `ID_Barang` int(11) NOT NULL,
  `Nama_Barang` varchar(100) NOT NULL,
  `Stok_Awal` int(11) NOT NULL,
  `Stok_Kosong` int(11) NOT NULL,
  `Harga_Beli_Barang_Baru_Operator` decimal(10,2) NOT NULL,
  `Harga_Isi_Ulang_Operator` decimal(10,2) NOT NULL,
  `Harga_Beli_Barang_Baru_Admin` decimal(10,2) NOT NULL,
  `Harga_Isi_Ulang_Admin` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `Barang`
--

INSERT INTO `Barang` (`ID_Barang`, `Nama_Barang`, `Stok_Awal`, `Stok_Kosong`, `Harga_Beli_Barang_Baru_Operator`, `Harga_Isi_Ulang_Operator`, `Harga_Beli_Barang_Baru_Admin`, `Harga_Isi_Ulang_Admin`) VALUES
(1, 'LPG 3KG', 79, 2449, 200000.00, 16000.00, 199900.00, 15900.00),
(2, 'CLEO GALON', 88, 369, 40000.00, 17000.00, 39900.00, 16900.00),
(4, 'AQUA GALON', 1000, 200, 51000.00, 19000.00, 50900.00, 18900.00),
(5, 'BRIGHT GAS', 1000, 200, 213000.00, 543000.00, 212900.00, 542900.00);

-- --------------------------------------------------------

--
-- Struktur dari tabel `Operator`
--

CREATE TABLE `Operator` (
  `id_operator` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `Penjualan`
--

CREATE TABLE `Penjualan` (
  `ID_Penjualan` int(11) NOT NULL,
  `ID_Barang` int(11) NOT NULL,
  `Jumlah` int(11) NOT NULL,
  `Tanggal` date NOT NULL,
  `Jenis_Transaksi` enum('Baru','Isi Ulang') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `Admin`
--
ALTER TABLE `Admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `Barang`
--
ALTER TABLE `Barang`
  ADD PRIMARY KEY (`ID_Barang`);

--
-- Indeks untuk tabel `Operator`
--
ALTER TABLE `Operator`
  ADD PRIMARY KEY (`id_operator`);

--
-- Indeks untuk tabel `Penjualan`
--
ALTER TABLE `Penjualan`
  ADD PRIMARY KEY (`ID_Penjualan`),
  ADD KEY `ID_Barang` (`ID_Barang`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `Admin`
--
ALTER TABLE `Admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `Barang`
--
ALTER TABLE `Barang`
  MODIFY `ID_Barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `Operator`
--
ALTER TABLE `Operator`
  MODIFY `id_operator` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `Penjualan`
--
ALTER TABLE `Penjualan`
  MODIFY `ID_Penjualan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
