<?php
// Konfigurasi koneksi ke database
$host = 'localhost';
$dbname = 'dbname';
$username = 'username';
$password = '@#password@#';

// Buat koneksi menggunakan PDO
try {
  $dsn = "mysql:host=$host;dbname=$dbname";
  $pdo = new PDO($dsn, $username, $password);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Koneksi database gagal: " . $e->getMessage());
}
?>