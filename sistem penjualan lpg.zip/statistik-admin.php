          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(0, 0, 0, 1);color:#fff;" class="card-header">
              <h5 class="card-title">Statistik (Admin)</h5>
            </div>
            <div class="card-body">
<div class="table-responsive">
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Nomor</th>
        <th>Nama Barang</th>
        <th>Stok Awal</th>
        <th>Sisa Stok</th>
        <th>Stok Kosong</th>
        <th>Beli Baru</th>
        <th>Isi Ulang</th>
        <th>Total Terjual</th>
        <th>Jumlah Pendapatan</th>
      </tr>
    </thead>
    <tbody>
      <?php
      
      include "koneksi.php";
      
      // Mengambil daftar barang dari database
$sql = "SELECT * FROM Barang";
$stmt = $pdo->query($sql);
$barang = $stmt->fetchAll(PDO::FETCH_ASSOC);
      $nomor = 1;
      $total_pendapatan_keseluruhan = 0; // Menyimpan total pendapatan keseluruhan

      foreach ($barang as $item) :
        $id_barang = $item['ID_Barang'];
        $stok_awal_banget = $item['stok_awal_banget'];
        $stok_awal = $item['Stok_Awal'];
        $stok_kosong = $item['Stok_Kosong'];

        // Menghitung total beli baru
        $sql_beli_baru = "SELECT SUM(Jumlah) AS total_beli_baru FROM Penjualan WHERE ID_Barang = :id_barang AND Jenis_Transaksi = 'Baru'";
        $stmt_beli_baru = $pdo->prepare($sql_beli_baru);
        $stmt_beli_baru->bindParam(':id_barang', $id_barang);
        $stmt_beli_baru->execute();
        $total_beli_baru = $stmt_beli_baru->fetch(PDO::FETCH_ASSOC)['total_beli_baru'];

        // Menghitung total isi ulang
        $sql_isi_ulang = "SELECT SUM(Jumlah) AS total_isi_ulang FROM Penjualan WHERE ID_Barang = :id_barang AND Jenis_Transaksi = 'Isi Ulang'";
        $stmt_isi_ulang = $pdo->prepare($sql_isi_ulang);
        $stmt_isi_ulang->bindParam(':id_barang', $id_barang);
        $stmt_isi_ulang->execute();
        $total_isi_ulang = $stmt_isi_ulang->fetch(PDO::FETCH_ASSOC)['total_isi_ulang'];

        // Menghitung total terjual dan jumlah pendapatan
        $total_terjual = $stok_awal_banget - $stok_awal;
        $jumlah_pendapatan = ($total_beli_baru * $item['Harga_Beli_Barang_Baru_Admin']) + ($total_isi_ulang * $item['Harga_Isi_Ulang_Admin']);
        
        // Menambahkan jumlah pendapatan ke total pendapatan keseluruhan
        $total_pendapatan_keseluruhan += $jumlah_pendapatan;

        // Format harga dengan Rp. di depannya
        $total_beli_baru_formatted = '' . number_format($total_beli_baru);
        $total_isi_ulang_formatted = '' . number_format($total_isi_ulang);
        $jumlah_pendapatan_formatted = 'Rp. ' . number_format($jumlah_pendapatan);
      ?>
      <tr>
        <td><?php echo $nomor++; ?></td>
        <td><?php echo $item['Nama_Barang']; ?></td>
        <td><?php echo $stok_awal_banget; ?></td>
        <td><?php echo $stok_awal; ?></td>
        <td><?php echo $stok_kosong; ?></td>
        <td><?php echo $total_beli_baru_formatted; ?></td>
        <td><?php echo $total_isi_ulang_formatted; ?></td>
        <td><?php echo $total_terjual; ?></td>
        <td><?php echo $jumlah_pendapatan_formatted; ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr>
        <th colspan="8">Total Pendapatan Keseluruhan</th>
        <th><?php echo 'Rp. ' . number_format($total_pendapatan_keseluruhan); ?></th>
      </tr>
    </tfoot>
  </table>
</div>

                
            </div>
          </div>