<?php
// Hapus cookie session_operator
setcookie('session_admin', '', time() - 3600, '/');

// Redirect kembali ke halaman login operator
header("Location: login.php");
exit;
?>
