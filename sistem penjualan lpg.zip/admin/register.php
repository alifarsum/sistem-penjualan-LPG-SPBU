<?php
require_once '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username_admin']) && isset($_POST['password'])) {
        $username_admin = $_POST['username_admin'];
        $password = $_POST['password'];

        try {
            // Mengecek apakah username_admin sudah terdaftar
            $sql = "SELECT * FROM Admin WHERE username_admin = :username_admin";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':username_admin', $username_admin);
            $stmt->execute();
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$admin) {
                // Username belum terdaftar, melakukan registrasi
                $sql = "INSERT INTO Admin (username_admin, password) VALUES (:username_admin, :password)";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':username_admin', $username_admin);
                $stmt->bindParam(':password', $password);
                $stmt->execute();

                echo "Registrasi berhasil. Silakan <a href='login.php'>login</a>.";
            } else {
                // Username sudah terdaftar
                echo "Username sudah terdaftar. Silakan gunakan username_admin lain.";
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());
            die("Terjadi kesalahan pada database.");
        }
    } else {
        echo "Silakan masukkan username_admin dan password.";
    }
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Admin Register </title>
    <?php include "../head.php";?>
  </head>
  <body>
    <div class="container mt-3 mb-3">
      <div class="row">
        <div class="col md-auto mt-3 mb-3">
<?php include "logo.php";?>
          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(116, 212, 66, 1);color:#fff;" class="card-header">
              <h5 class="card-title">Register Admin</h5>
            </div>
            <div class="card-body">
                <?php if (isset($errorMessage)) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $errorMessage; ?>
                    </div>
                <?php } ?>
<form method="POST" action="register.php">
    <div class="mb-3">
        <label for="username_admin" class="form-label">Username:</label>
        <input type="text" id="username_admin" name="username_admin" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password:</label>
        <input type="password" id="password" name="password" class="form-control" required>
    </div>
    <div class="mb-3">
        <button type="submit" class="btn btn-primary">Register</button>
    </div>
</form>

            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include "../footer.php";?>
  </body>
</html>

