<?php
session_start();

// Memeriksa apakah sesi operator telah terdaftar
if (!isset($_COOKIE['session_admin'])) {
    header("Location: login.php");
    exit;
}

// Mendapatkan username operator dari cookie sesi
$username_op = $_COOKIE['session_admin'];

?>
<?php
require_once '../koneksi.php';

if (isset($_GET['id'])) {
    $id_barang = $_GET['id'];

    // Mengambil data barang berdasarkan ID
    $sql = "SELECT * FROM Barang WHERE ID_Barang = :id_barang";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id_barang', $id_barang);
    $stmt->execute();
    $barang = $stmt->fetch(PDO::FETCH_ASSOC);

    // Jika barang tidak ditemukan, kembalikan ke halaman admin
    if (!$barang) {
        header("Location: admin.php");
        exit;
    }
} else {
    // Jika tidak ada ID yang diberikan, kembalikan ke halaman admin
    header("Location: admin.php");
    exit;
}

if (isset($_POST['submit'])) {
    // Mengambil data dari form
    $nama_barang = $_POST['nama_barang'];
    $stok_awal_banget = $_POST['stok_awal_banget'];
    $stok_awal = $_POST['stok_awal'];
    $stok_kosong = $_POST['stok_kosong'];
    $harga_beli_baru_admin = $_POST['harga_beli_baru_admin'];
    $harga_isi_ulang_admin = $_POST['harga_isi_ulang_admin'];
    $harga_beli_baru_operator = $_POST['harga_beli_baru_operator'];
    $harga_isi_ulang_operator = $_POST['harga_isi_ulang_operator'];

    // Memperbarui data barang di database
    $sql = "UPDATE Barang SET Nama_Barang = :nama_barang, stok_awal_banget = :stok_awal_banget, Stok_Awal = :stok_awal, Stok_Kosong = :stok_kosong, 
            Harga_Beli_Barang_Baru_Admin = :harga_beli_baru_admin, Harga_Isi_Ulang_Admin = :harga_isi_ulang_admin, 
            Harga_Beli_Barang_Baru_Operator = :harga_beli_baru_operator, Harga_Isi_Ulang_Operator = :harga_isi_ulang_operator
            WHERE ID_Barang = :id_barang";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':nama_barang', $nama_barang);
    $stmt->bindParam(':stok_awal_banget', $stok_awal_banget);
    $stmt->bindParam(':stok_awal', $stok_awal);
    $stmt->bindParam(':stok_kosong', $stok_kosong);
    $stmt->bindParam(':harga_beli_baru_admin', $harga_beli_baru_admin);
    $stmt->bindParam(':harga_isi_ulang_admin', $harga_isi_ulang_admin);
    $stmt->bindParam(':harga_beli_baru_operator', $harga_beli_baru_operator);
    $stmt->bindParam(':harga_isi_ulang_operator', $harga_isi_ulang_operator);
    $stmt->bindParam(':id_barang', $id_barang);

    if ($stmt->execute()) {
        header("Location: admin.php");
        exit;
    } else {
        echo "Gagal memperbarui barang.";
    }
}
?>



<!DOCTYPE html>
<html>
  <head>
          <title>Sistem manajemen penjualan LPG,Galon minuman</title>
      <?php include "../head.php";?>
  </head>
  <body>
    <div class="container mt-3 mb-3">
      <div class="row">
        <div class="col md-auto mt-3 mb-3">
<?php include "logo.php";?>          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(116, 212, 66, 1);color:#fff;" class="card-header">
              <h5 class="card-title">Sistem manajemen penjualan LPG,Galon minuman</h5>
            </div>
            <div class="card-body">

        <form action="edit_barang.php?id=<?php echo $barang['ID_Barang']; ?>" method="POST">
            <div class="mb-3">
                <label for="nama_barang" class="form-label">Nama Barang:</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" value="<?php echo $barang['Nama_Barang']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="stok_awal_banget" class="form-label">Stok Awal Barang(untuk penghitungan):</label>
                <input type="number" class="form-control" id="stok_awal_banget" name="stok_awal_banget" value="<?php echo $barang['stok_awal_banget']; ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="stok_awal" class="form-label">Stok Awal Barang:</label>
                <input type="number" class="form-control" id="stok_awal" name="stok_awal" value="<?php echo $barang['Stok_Awal']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="stok_kosong" class="form-label">Stok Kosong Barang:</label>
                <input type="number" class="form-control" id="stok_kosong" name="stok_kosong" value="<?php echo $barang['Stok_Kosong']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="harga_beli_baru_admin" class="form-label">Harga Beli Barang Baru (Admin):</label>
                <input type="text" class="form-control" id="harga_beli_baru_admin" name="harga_beli_baru_admin" value="<?php echo $barang['Harga_Beli_Barang_Baru_Admin']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="harga_isi_ulang_admin" class="form-label">Harga Isi Ulang Barang (Admin):</label>
                <input type="text" class="form-control" id="harga_isi_ulang_admin" name="harga_isi_ulang_admin" value="<?php echo $barang['Harga_Isi_Ulang_Admin']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="harga_beli_baru_operator" class="form-label">Harga Beli Barang Baru (Operator):</label>
                <input type="text" class="form-control" id="harga_beli_baru_operator" name="harga_beli_baru_operator" value="<?php echo $barang['Harga_Beli_Barang_Baru_Operator']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="harga_isi_ulang_operator" class="form-label">Harga Isi Ulang Barang (Operator):</label>
                <input type="text" class="form-control" id="harga_isi_ulang_operator" name="harga_isi_ulang_operator" value="<?php echo $barang['Harga_Isi_Ulang_Operator']; ?>" required>
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
            </div>
          </div>
          
          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(116, 212, 66, 1);color:#fff;" class="card-header">
              <h5 class="card-title">Statistik Hari ini</h5>
            </div>
            <div class="card-body">
<?php include "daily.php";?>
                
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
      <?php include "../footer.php";?>
  </body>
</html>