<?php
session_start();

// Memeriksa apakah sesi operator telah terdaftar
if (!isset($_COOKIE['session_admin'])) {
    header("Location: login.php");
    exit;
}

// Mendapatkan username operator dari cookie sesi
$username_op = $_COOKIE['session_admin'];

?>
<?php
require_once '../koneksi.php';

try {
    // Menghapus data penjualan hari ini
    $sql = "DELETE FROM Penjualan";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    // Mengarahkan kembali ke halaman laporan-operator setelah penghapusan berhasil
    header("Location: laporan-operator.php");
    exit;
} catch (PDOException $e) {
    error_log($e->getMessage());
    die("Terjadi kesalahan pada database.");
}
?>
