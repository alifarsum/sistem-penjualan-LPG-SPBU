<?php
session_start();

// Memeriksa apakah sesi operator telah terdaftar
if (!isset($_COOKIE['session_admin'])) {
    header("Location: login.php");
    exit;
}

// Mendapatkan username operator dari cookie sesi
$username_op = $_COOKIE['session_admin'];

?>
<?php
include '../koneksi.php';

// Fungsi untuk memperbarui stok barang
function updateStok($id_barang,$stok_awal_banget, $stok_awal, $stok_kosong)
{
  global $pdo;
  $sql = "UPDATE Barang SET stok_awal_banget = :stok_awal_banget ,Stok_Awal = :stok_awal, Stok_Kosong = :stok_kosong WHERE ID_Barang = :id_barang";
  $stmt = $pdo->prepare($sql);
  $stmt->bindParam(':stok_awal_banget', $stok_awal_banget);
  $stmt->bindParam(':stok_awal', $stok_awal);
  $stmt->bindParam(':stok_kosong', $stok_kosong);
  $stmt->bindParam(':id_barang', $id_barang);
  $stmt->execute();
}

// Fungsi untuk menghapus barang
function deleteBarang($id_barang)
{
  global $pdo;
  $sql = "DELETE FROM Barang WHERE ID_Barang = :id_barang";
  $stmt = $pdo->prepare($sql);
  $stmt->bindParam(':id_barang', $id_barang);
  $stmt->execute();
}

// Mengambil daftar barang dari database
$sql = "SELECT * FROM Barang";
$stmt = $pdo->query($sql);
$barang = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>



<!DOCTYPE html>
<html>
  <head>
          <title>Tambah barang</title>
      <?php include "../head.php";?>
  </head>
  <body>
    <div class="container mt-3 mb-3">
      <div class="row">
        <div class="col md-auto mt-3 mb-3">
<?php include "logo.php";?>
          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(116, 212, 66, 1);color:#fff;"class="card-header">
              <h5 class="card-title">Sistem manajemen penjualan LPG,Galon minuman</h5>
            </div>
            <div class="card-body">
                

 <h2>Tambah Barang</h2>
    <form action="admin.php" method="POST">
      <div class="mb-3">
        <label for="nama_barang" class="form-label">Nama Barang:</label>
        <input type="text" id="nama_barang" name="nama_barang" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="stok_awal_banget" class="form-label">Stok Awal Barang (Untuk hitungan):</label>
        <input type="number" id="stok_awal_banget" name="stok_awal_banget" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="stok_awal" class="form-label">Stok Awal Barang:</label>
        <input type="number" id="stok_awal" name="stok_awal" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="stok_kosong" class="form-label">Stok Kosong Barang:</label>
        <input type="number" id="stok_kosong" name="stok_kosong" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="harga_beli_baru_admin" class="form-label">Harga Beli Barang Baru (Admin):</label>
        <input type="number" placeholder="199900" id="harga_beli_baru_admin" name="harga_beli_baru_admin" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="harga_isi_ulang_admin" class="form-label">Harga Isi Ulang Barang (Admin):</label>
        <input type="number" placeholder="15900" id="harga_isi_ulang_admin" name="harga_isi_ulang_admin" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="harga_beli_baru_operator" class="form-label">Harga Beli Barang Baru (Operator):</label>
        <input type="number" placeholder="200000" id="harga_beli_baru_operator" name="harga_beli_baru_operator" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="harga_isi_ulang_operator" class="form-label">Harga Isi Ulang Barang (Operator):</label>
        <input type="number" placeholder="16000" id="harga_isi_ulang_operator" name="harga_isi_ulang_operator" class="form-control" required>
      </div>
      <input type="submit" name="submit" value="Tambah Barang" class="btn btn-primary">
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/admin/";
  echo $url;
?>admin.php" type="button"class="btn btn-primary mt-2 mb-2">Refresh Halaman</a>
    </form>

    <?php
    if (isset($_POST['submit'])) {
      // Mengambil data dari form
      $nama_barang = $_POST['nama_barang'];
      $stok_awal_banget = $_POST['stok_awal_banget'];
      $stok_awal = $_POST['stok_awal'];
      $stok_kosong = $_POST['stok_kosong'];
      $harga_beli_baru_admin = $_POST['harga_beli_baru_admin'];
      $harga_isi_ulang_admin = $_POST['harga_isi_ulang_admin'];
      $harga_beli_baru_operator = $_POST['harga_beli_baru_operator'];
      $harga_isi_ulang_operator = $_POST['harga_isi_ulang_operator'];

      // Menyimpan data ke database
      $sql = "INSERT INTO Barang (Nama_Barang, stok_awal_banget, Stok_Awal, Stok_Kosong, Harga_Beli_Barang_Baru_Admin, Harga_Isi_Ulang_Admin, Harga_Beli_Barang_Baru_Operator, Harga_Isi_Ulang_Operator) 
              VALUES (:nama_barang, :stok_awal_banget, :stok_awal, :stok_kosong, :harga_beli_baru_admin, :harga_isi_ulang_admin, :harga_beli_baru_operator, :harga_isi_ulang_operator)";
      $stmt = $pdo->prepare($sql);
      $stmt->bindParam(':nama_barang', $nama_barang);
            $stmt->bindParam(':stok_awal_banget', $stok_awal_banget);
      $stmt->bindParam(':stok_awal', $stok_awal);
      $stmt->bindParam(':stok_kosong', $stok_kosong);
      $stmt->bindParam(':harga_beli_baru_admin', $harga_beli_baru_admin);
      $stmt->bindParam(':harga_isi_ulang_admin', $harga_isi_ulang_admin);
      $stmt->bindParam(':harga_beli_baru_operator', $harga_beli_baru_operator);
      $stmt->bindParam(':harga_isi_ulang_operator', $harga_isi_ulang_operator);

      if ($stmt->execute()) {
          echo "<p class='alert alert-success'>Barang berhasil ditambahkan.</p>";
      } else {
          echo "<p class='alert alert-danger'>Gagal menambahkan barang.</p>";
      }
    }
    ?>

            </div>
          </div>
          
          
    <h3>Daftar Barang</h3>
<div class="table table-responsive">
        <table class="table table-hover-bordered">
      <thead>
        <tr>
          <th>Nama Barang</th>
          <th>Stok Awal (utk hitungan)</th>
          <th>Stok Awal</th>
          <th>Stok Kosong</th>
          <th>Harga Beli Barang Baru (Admin)</th>
          <th>Harga Isi Ulang (Admin)</th>
          <th>Harga Beli Barang Baru (Operator)</th>
          <th>Harga Isi Ulang (Operator)</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($barang as $item) : ?>
          <tr>
            <td><?php echo $item['Nama_Barang']; ?></td>
            <td><?php echo $item['stok_awal_banget']; ?></td>
            <td><?php echo $item['Stok_Awal']; ?></td>
            <td><?php echo $item['Stok_Kosong']; ?></td>
            <td><?php echo $item['Harga_Beli_Barang_Baru_Admin']; ?></td>
            <td><?php echo $item['Harga_Isi_Ulang_Admin']; ?></td>
            <td><?php echo $item['Harga_Beli_Barang_Baru_Operator']; ?></td>
            <td><?php echo $item['Harga_Isi_Ulang_Operator']; ?></td>
            <td>
  <a href="edit_barang.php?id=<?php echo $item['ID_Barang']; ?>" class="btn btn-primary">Edit</a>
  <a href="hapus_barang.php?id=<?php echo $item['ID_Barang']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus barang ini?')" class="btn btn-danger">Hapus</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
    </table>
</div>






<h3>Tabel dan Statistik Penjualan</h3>
<div class="table-responsive">
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Nomor</th>
        <th>Nama Barang</th>
        <th>Stok Awal (untuk hitungan)</th>
        <th>Stok Kosong</th>
        <th>Total Beli Baru</th>
        <th>Total Isi Ulang</th>
        <th>Total Terjual</th>
        <th>Jumlah Pendapatan</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $nomor = 1;
      $total_pendapatan_keseluruhan = 0; // Menyimpan total pendapatan keseluruhan

      foreach ($barang as $item) :
        $id_barang = $item['ID_Barang'];
        $stok_awal_banget = $item['stok_awal_banget'];
        $stok_awal = $item['Stok_Awal'];
        $stok_kosong = $item['Stok_Kosong'];

        // Menghitung total beli baru
        $sql_beli_baru = "SELECT SUM(Jumlah) AS total_beli_baru FROM Penjualan WHERE ID_Barang = :id_barang AND Jenis_Transaksi = 'Baru'";
        $stmt_beli_baru = $pdo->prepare($sql_beli_baru);
        $stmt_beli_baru->bindParam(':id_barang', $id_barang);
        $stmt_beli_baru->execute();
        $total_beli_baru = $stmt_beli_baru->fetch(PDO::FETCH_ASSOC)['total_beli_baru'];

        // Menghitung total isi ulang
        $sql_isi_ulang = "SELECT SUM(Jumlah) AS total_isi_ulang FROM Penjualan WHERE ID_Barang = :id_barang AND Jenis_Transaksi = 'Isi Ulang'";
        $stmt_isi_ulang = $pdo->prepare($sql_isi_ulang);
        $stmt_isi_ulang->bindParam(':id_barang', $id_barang);
        $stmt_isi_ulang->execute();
        $total_isi_ulang = $stmt_isi_ulang->fetch(PDO::FETCH_ASSOC)['total_isi_ulang'];

        // Menghitung total terjual dan jumlah pendapatan
        $total_terjual = $stok_awal_banget - $stok_awal;
        $jumlah_pendapatan = ($total_beli_baru * $item['Harga_Beli_Barang_Baru_Admin']) + ($total_isi_ulang * $item['Harga_Isi_Ulang_Admin']);
        
        // Menambahkan jumlah pendapatan ke total pendapatan keseluruhan
        $total_pendapatan_keseluruhan += $jumlah_pendapatan;

        // Format harga dengan Rp. di depannya
        $total_beli_baru_formatted = 'Rp. ' . number_format($total_beli_baru);
        $total_isi_ulang_formatted = 'Rp. ' . number_format($total_isi_ulang);
        $jumlah_pendapatan_formatted = 'Rp. ' . number_format($jumlah_pendapatan);
      ?>
      <tr>
        <td><?php echo $nomor++; ?></td>
        <td><?php echo $item['Nama_Barang']; ?></td>
        <td><?php echo $stok_awal_banget; ?></td>
        <td><?php echo $stok_kosong; ?></td>
        <td><?php echo $total_beli_baru_formatted; ?></td>
        <td><?php echo $total_isi_ulang_formatted; ?></td>
        <td><?php echo $total_terjual; ?></td>
        <td><?php echo $jumlah_pendapatan_formatted; ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr>
        <th colspan="7">Total Pendapatan Keseluruhan</th>
        <th><?php echo 'Rp. ' . number_format($total_pendapatan_keseluruhan); ?></th>
      </tr>
    </tfoot>
  </table>
</div>













          <!-- batas -->
        </div>
      </div>
    </div>
    </div>
      <?php include "../footer.php";?>
  </body>
</html>