<?php
session_start();

// Memeriksa apakah sesi operator telah terdaftar
if (!isset($_COOKIE['session_admin'])) {
    header("Location: login.php");
    exit;
}

// Mendapatkan username operator dari cookie sesi
$username_op = $_COOKIE['session_admin'];

?>
<?php
require_once '../koneksi.php';

if (isset($_GET['id'])) {
    $id_barang = $_GET['id'];

    // Menghapus barang berdasarkan ID
    $sql = "DELETE FROM Barang WHERE ID_Barang = :id_barang";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id_barang', $id_barang);

    if ($stmt->execute()) {
        header("Location: admin.php");
        exit;
    } else {
        echo "Gagal menghapus barang.";
    }
} else {
    // Jika tidak ada ID yang diberikan, kembalikan ke halaman admin
    header("Location: admin.php");
    exit;
}
?>
