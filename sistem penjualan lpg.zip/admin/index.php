<?php
session_start();

// Memeriksa apakah sesi operator telah terdaftar
if (!isset($_COOKIE['session_admin'])) {
    header("Location: login.php");
    exit;
}

// Mendapatkan username operator dari cookie sesi
$username_op = $_COOKIE['session_admin'];

?>


<!DOCTYPE html>
<html>
  <head>
          <title>Dashboard admin</title>
      <?php include "../head.php";?>
  </head>
  <body>
    <div class="container mt-3 mb-3">
      <div class="row">
        <div class="col md-auto mt-3 mb-3">
<?php include "logo.php";?>
          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(116, 212, 66, 1);color:#fff;" class="card-header">
              <h5 class="card-title">Sistem manajemen penjualan LPG,Galon minuman</h5>
            </div>
            <div class="card-body">
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/admin/";
  echo $url;
?>admin.php" type="button"class="btn btn-primary mt-2 mb-2">Tambah,Edit,Delete Barang</a>
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/admin/";
  echo $url;
?>laporan-operator.php" type="button"class="btn btn-primary mt-2 mb-2">Laporan Penjualan operator</a>
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/admin/";
  echo $url;
?>laporan-admin.php" type="button"class="btn btn-primary mt-2 mb-2">Laporan Penjualan admin</a>
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/admin/";
  echo $url;
?>logout.php" type="button"class="btn btn-primary mt-2 mb-2">Logout</a>




<hr>

<p>Selamat datang,Admin.</p>
Jika ingin kembali ke halaman utama admin,Klik gambar logo Pertamina.
<br>
Dibawah ini adalah statistik penjualan barang untuk admin dan operator.Logika penghitungan jumlah pendapatan dari total barang terjual adalah:
<br>
<!--textarea class="form-control" readonly cols="6" rows="6">
            // Menghitung total terjual dan jumlah pendapatan
        $total_terjual = $stok_awal_banget - $stok_awal;
        $jumlah_pendapatan = ($total_beli_baru * $item['Harga_Beli_Barang_Baru_Operator']) + ($total_isi_ulang * $item['Harga_Isi_Ulang_Operator']);
</textarea-->



    <code>
        // Menghitung total terjual dan jumlah pendapatan
        $total_terjual = $stok_awal_banget - $stok_awal;
        $jumlah_pendapatan = ($total_beli_baru * $item['Harga_Beli_Barang_Baru_Operator']) + ($total_isi_ulang * $item['Harga_Isi_Ulang_Operator']);
    </code>
    
    
    <br>
    <p>Penjelasan Tabel:</p>
Logika input data penjualan operator:
<br>
Jika operator menginput data misalnya:
<br>
stok awal LPG 3KG adalah 1000,stok kosong 1000.kemudian
pak rudi membeli 1 buah LPG 3kg baru(tanpa isi ulang).maka,hasil input datanya adalah stok awal berkurang, namun pengurangannya tadi tidak masuk ke database stok kosong.
pada database,sisa stok dari LPG 3kg tadi adalah 999.Dan Stok Kosongnya tetap 1000 (karena membeli barang/tabung baru).
<br>
berbeda dengan isi ulang,jika ada pembelian isi ulang..maka pengurangan dari stok awal tadi akan masuk ke stok kosong.
<br>
contoh: pak sucipto membeli LPG 3kg isi ulang.Stok awal LPG 3kg nya adalah 1000.Stok kosongnya adalah 1000.nanti setelah operator memasukkan input penjualan,hasil pada jumlah stok awal akan berkurang menjadi 999,dan jumlah stok kosong akan beratambah menjadi 1001.
<br>
Dan soal harganya,sudah disesuaikan antara harga untuk admin dan harga untuk operator.
<br>
Misal:
<br>
LPG 3KG :
<br>
harga beli baru (operator): Rp.200.000
<br>
harga beli baru (admin): Rp.199.900
<br>
harga isi ulang (operator): Rp.16000
<br>
harga isi ulang (admin): Rp.15900


<br>


            </div>
          </div>
          
<?php 
include "statistik-admin.php";
include "statistik-operator.php";
?>
        </div>
      </div>
    </div>
    </div>
      <?php include "../footer.php";?>
  </body>
</html>