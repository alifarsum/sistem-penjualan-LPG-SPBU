<link rel="apple-touch-icon" sizes="57x57" href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="<?php  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";  echo $url;?>/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="<?php  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";  echo $url;?>/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="<?php  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";  echo $url;?>/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="<?php  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";  echo $url;?>/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?php  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";  echo $url;?>/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href=<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>"/favicon-16x16.png">
<link rel="manifest" href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>/manifest.json">
<meta name="msapplication-TileColor" content="rgba(171, 22, 22, 0.8)">
<meta name="msapplication-TileImage" content="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/gambar";
  echo $url;
?>/ms-icon-144x144.png">
<meta name="theme-color" content="rgba(171, 22, 22, 0.8)">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Sniglet" />
    <meta name="theme-color" content="rgba(171, 22, 22, 0.8)">
    
    
