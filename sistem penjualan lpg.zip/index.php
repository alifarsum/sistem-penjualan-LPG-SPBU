<!DOCTYPE html>
<html>
  <head>
          <title>Sistem manajemen penjualan LPG,Galon minuman</title>
      <?php include "head.php";?>
          <link rel="manifest" href="/web.webmanifest">
    
  </head>
  <body>
    <div class="container mt-3 mb-3">
      <div class="row">
        <div class="col md-auto mt-3 mb-3">
          <center clasa="mt-2 mb-2">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Pertamina_Logo.svg/1600px-Pertamina_Logo.svg.png" class="img img-rounded" height="50%" width="50%">
          </center>
          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(116, 212, 66, 1);color:#fff;" class="card-header">
              <h5 class="card-title">Sistem manajemen penjualan LPG,Galon minuman</h5>
            </div>
            <div class="card-body">
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/admin";
  echo $url;
?>" type="button"class="btn btn-primary mt-2 mb-2">Admin</a>
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/operator";
  echo $url;
?>" type="button"class="btn btn-primary mt-2 mb-2">Operator</a>
            </div>
          </div>
          
<?php 
include "./admin/statistik-admin.php";
include "./admin/statistik-operator.php";
?>
        </div>
      </div>
    </div>
    </div>
      <?php include "footer.php";?>
    <script src="/register.js"></script>
  </body>
</html>