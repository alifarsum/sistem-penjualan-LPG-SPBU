-- Tabel Barang
CREATE TABLE Barang (
  ID_Barang INT AUTO_INCREMENT PRIMARY KEY,
  Nama_Barang VARCHAR(100) NOT NULL,
  Stok_Awal INT NOT NULL,
  Stok_Kosong INT NOT NULL,
  Harga_Beli_Barang_Baru_Operator DECIMAL(10, 2) NOT NULL,
  Harga_Isi_Ulang_Operator DECIMAL(10, 2) NOT NULL,
  Harga_Beli_Barang_Baru_Admin DECIMAL(10, 2) NOT NULL,
  Harga_Isi_Ulang_Admin DECIMAL(10, 2) NOT NULL
);

-- Tabel Penjualan
CREATE TABLE Penjualan (
  ID_Penjualan INT AUTO_INCREMENT PRIMARY KEY,
  ID_Barang INT NOT NULL,
  Jumlah INT NOT NULL,
  Tanggal DATE NOT NULL,
  FOREIGN KEY (ID_Barang) REFERENCES Barang(ID_Barang)
);

-- Tabel Admin
CREATE TABLE Admin (
  id_admin INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(50) NOT NULL
);

-- Tabel Operator
CREATE TABLE Operator (
  id_operator INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(50) NOT NULL
);
