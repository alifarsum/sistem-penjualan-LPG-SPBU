          <center clasa="mt-2 mb-2">
          <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/operator/";
  echo $url;
?>">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Pertamina_Logo.svg/1600px-Pertamina_Logo.svg.png" class="img img-rounded" height="50%" width="50%">
            </a>
          </center>