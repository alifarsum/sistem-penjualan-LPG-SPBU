<?php
session_start();
require_once '../koneksi.php';

// Fungsi untuk menghasilkan token CSRF
function generateCSRFToken()
{
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Fungsi untuk memeriksa validitas token CSRF
function validateCSRFToken($token)
{
    return isset($_SESSION['csrf_token']) && $_SESSION['csrf_token'] === $token;
}

$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username_op']) && isset($_POST['password']) && isset($_POST['csrf_token'])) {
        $username_op = $_POST['username_op'];
        $password = $_POST['password'];
        $csrf_token = $_POST['csrf_token'];

        // Memeriksa validitas token CSRF
        if (validateCSRFToken($csrf_token)) {
            try {
                // Mengecek kecocokan username_op dan password
                $sql = "SELECT * FROM Operator WHERE username_op = :username_op AND password = :password";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':username_op', $username_op);
                $stmt->bindParam(':password', $password);
                $stmt->execute();
                $operator = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($operator) {
                    setcookie('session_op', $username_op, time() + (86400 * 30), '/'); // Set cookie sesi operator
                    header("Location: index.php");
                    exit;
                } else {
                    $errorMessage = "Username atau password salah.";
                }
            } catch (PDOException $e) {
                error_log($e->getMessage());
                die("Terjadi kesalahan pada database.");
            }
        } else {
            $errorMessage = "Token CSRF tidak valid.";
        }
    } else {
        $errorMessage = "Silakan masukkan username_op dan password.";
    }
}

// Mendapatkan token CSRF
$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Operator Login</title>
    <?php include "../head.php";?>
  </head>
  <body>
    <div class="container mt-3 mb-3">
      <div class="row">
        <div class="col md-auto mt-3 mb-3">
          <center clasa="mt-2 mb-2">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Pertamina_Logo.svg/1600px-Pertamina_Logo.svg.png" class="img img-rounded" height="50%" width="50%">
          </center>
          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(116, 212, 66, 1);color:#fff;" class="card-header">
              <h5 class="card-title">Login Operator</h5>
            </div>
            <div class="card-body">
                <?php if (!empty($errorMessage)) { ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $errorMessage; ?>
                    </div>
                <?php } ?>
                <form method="POST" action="login-operator.php" class="mb-3">
                    <div class="mb-3">
                        <label for="username_op">Username:</label>
                       <input type="text" id="username_op" name="username_op" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary md-2 mt-2 mb-2">Login</button>
                        <a type="button" class="btn btn-primary md-2 mt-2 mb-2" href="register-operator.php">Register</a>
                    </div>
                </form>

            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include "../footer.php";?>
  </body>
</html>
