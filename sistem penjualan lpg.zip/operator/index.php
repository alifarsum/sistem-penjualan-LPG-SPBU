<?php
session_start();

// Memeriksa apakah sesi operator telah terdaftar
if (!isset($_COOKIE['session_op'])) {
    header("Location: login-operator.php");
    exit;
}

// Mendapatkan username operator dari cookie sesi
$username_op = $_COOKIE['session_operator'];

?>




<!DOCTYPE html>
<html>
  <head>
          <title>Dashboard Operator</title>
      <?php include "../head.php";?>
  </head>
  <body>
    <div class="container mt-3 mb-3">
      <div class="row">
        <div class="col md-auto mt-3 mb-3">
<?php include "logo.php";?>
          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(116, 212, 66, 1);color:#fff;" class="card-header">
              <h5 class="card-title">Sistem manajemen penjualan LPG,Galon minuman</h5>
            </div>
            <div class="card-body">
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/operator/";
  echo $url;
?>operator.php" type="button"class="btn btn-primary mt-2 mb-2">Input Data Penjualan</a>
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/operator/";
  echo $url;
?>laporan-operator.php" type="button"class="btn btn-primary mt-2 mb-2">Laporan Penjualan operator</a>
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/operator/";
  echo $url;
?>laporan-admin.php" type="button"class="btn btn-primary mt-2 mb-2">Laporan Penjualan admin</a>
                <a href="<?php
  $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
  $url = $protocol . "://" . $_SERVER['SERVER_NAME']."/operator/";
  echo $url;
?>logout.php" type="button"class="btn btn-primary mt-2 mb-2">Logout</a>
            </div>
          </div>
          
<?php include "../statistik-operator.php";?>
        </div>
      </div>
    </div>
    </div>
      <?php include "../footer.php";?>
  </body>
</html>