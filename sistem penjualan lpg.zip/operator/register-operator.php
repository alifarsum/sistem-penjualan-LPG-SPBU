<?php
session_start();

require_once '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_op = $_POST['username_op'];
    $password = $_POST['password'];

    // Memeriksa apakah username_op sudah digunakan
    $sql = "SELECT * FROM Operator WHERE username_op = :username_op";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':username_op', $username_op);
    $stmt->execute();
    $operator = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($operator) {
        $notification = "Username sudah digunakan. Silakan pilih username_op lain.";
        $_SESSION['notification_type'] = "danger";
    } else {
        // Menyimpan data operator ke database
        $sql = "INSERT INTO Operator (username_op, password) VALUES (:username_op, :password)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':username_op', $username_op);
        $stmt->bindParam(':password', $password);
        $stmt->execute();

        $notification = "Registrasi berhasil. Silakan login.";
        $_SESSION['notification_type'] = "success";
    }
}
?>

<html>
  <head>
    <title>Operator Register</title>
    <?php include "../head.php";?>
    <style>
      .card-title {
        color: #fff;
      }
    </style>
  </head>
  <body>
    <div class="container mt-3 mb-3">
      <div class="row">
        <div class="col-md-auto mt-3 mb-3">
          <?php include "logo.php";?>
          <div class="card mt-3 mb-3">
            <div style="background-color: rgba(116, 212, 66, 1); color: #fff;" class="card-header">
              <h5 class="card-title">Register Operator</h5>
            </div>
            <div class="card-body">
              <?php if (!empty($notification)) : ?>
                <div class="alert alert-<?php echo isset($_SESSION['notification_type']) ? $_SESSION['notification_type'] : 'success'; ?>" role="alert">
                  <?php echo $notification; ?>
                </div>
              <?php endif; ?>
              <form method="POST">
                <div class="mb-3">
                  <label for="username_op" class="form-label">Username:</label>
                  <input type="text" class="form-control" name="username_op" required>
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label">Password:</label>
                  <input type="password" class="form-control" name="password" required>
                </div>
                <div class="mb-3">
                  <button type="submit" class="btn btn-primary">Register</button>
                                          <a type="button" class="btn btn-primary md-2 mt-2 mb-2" href="register-operator.php">Register</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include "../footer.php";?>
  </body>
</html>
