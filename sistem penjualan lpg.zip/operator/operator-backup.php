<?php
require_once '../koneksi.php';

$notification = '';

try {
    // Mendapatkan daftar barang dari database
    $sql = "SELECT * FROM Barang";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $barang = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Memproses input penjualan
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['id_barang']) && isset($_POST['jumlah_terjual']) && isset($_POST['jenis_transaksi'])) {
            $id_barang = $_POST['id_barang'];
            $jumlah_terjual = $_POST['jumlah_terjual'];
            $jenis_transaksi = $_POST['jenis_transaksi'];

            // Mendapatkan informasi stok awal dan stok kosong dari barang yang dijual
            $sql = "SELECT Stok_Awal, Stok_Kosong FROM Barang WHERE ID_Barang = :id_barang";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':id_barang', $id_barang);
            $stmt->execute();
            $barang_info = $stmt->fetch(PDO::FETCH_ASSOC);

            $stok_awal = $barang_info['Stok_Awal'];
            $stok_kosong = $barang_info['Stok_Kosong'];

            // Mengurangi stok awal dan menambah stok kosong berdasarkan jenis transaksi
            if ($jenis_transaksi === 'Baru') {
                $stok_awal -= $jumlah_terjual;
            } elseif ($jenis_transaksi === 'Isi Ulang') {
                $stok_awal -= $jumlah_terjual;
                $stok_kosong += $jumlah_terjual;
            }

            // Mengupdate stok awal dan stok kosong ke database
            $sql = "UPDATE Barang SET Stok_Awal = :stok_awal, Stok_Kosong = :stok_kosong WHERE ID_Barang = :id_barang";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':stok_awal', $stok_awal);
            $stmt->bindParam(':stok_kosong', $stok_kosong);
            $stmt->bindParam(':id_barang', $id_barang);
            $stmt->execute();

            // Menyimpan data penjualan ke database
            $sql = "INSERT INTO Penjualan (ID_Barang, Jumlah, Tanggal, Jenis_Transaksi) 
                    VALUES (:id_barang, :jumlah_terjual, CURDATE(), :jenis_transaksi)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':id_barang', $id_barang);
            $stmt->bindParam(':jumlah_terjual', $jumlah_terjual);
            $stmt->bindParam(':jenis_transaksi', $jenis_transaksi);
            $stmt->execute();

            $notification = 'Data penjualan berhasil disimpan.';
        } else {
            $notification = 'Gagal menyimpan data penjualan.';
        }
    }
} catch (PDOException $e) {
    error_log($e->getMessage());
    die("Terjadi kesalahan pada database.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Operator - Input Penjualan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Operator - Input Penjualan</h1>
        <?php if (!empty($notification)) : ?>
           
            <div class="alert alert-<?php echo isset($_SESSION['notification_type']) ? $_SESSION['notification_type'] : 'success'; ?>" role="alert">
                <?php echo $notification; ?>
            </div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="id_barang" class="form-label">Nama Barang:</label>
                <select name="id_barang" class="form-select" required>
                    <?php foreach ($barang as $item): ?>
                        <option value="<?php echo $item['ID_Barang']; ?>"><?php echo $item['Nama_Barang']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="jumlah_terjual" class="form-label">Jumlah Terjual:</label>
                <input type="number" class="form-control" name="jumlah_terjual" required>
            </div>
            <div class="mb-3">
                <label for="jenis_transaksi" class="form-label">Jenis Transaksi:</label>
                <select name="jenis_transaksi" class="form-select" required>
                    <option value="Baru">Baru</option>
                    <option value="Isi Ulang">Isi Ulang</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
        <br>
        <a href="laporan-operator.php">Lihat Laporan Penjualan</a>
    </div>
</body>
</html>
