<?php
session_start();

// Memeriksa apakah sesi operator telah terdaftar
if (!isset($_COOKIE['session_op'])) {
    header("Location: login.php");
    exit;
}

// Mendapatkan username operator dari cookie sesi
$username_op = $_COOKIE['session_op'];

?>
<?php
require_once '../koneksi.php';

try {
    // Menghapus data penjualan hari ini
    $sql = "DELETE FROM Penjualan";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();


} catch (PDOException $e) {
    error_log($e->getMessage());
    die("Terjadi kesalahan pada database.");
}
?>
