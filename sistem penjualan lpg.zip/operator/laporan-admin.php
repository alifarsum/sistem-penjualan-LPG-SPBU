<?php
session_start();

// Memeriksa apakah sesi operator telah terdaftar
if (!isset($_COOKIE['session_op'])) {
    header("Location: login-operator.php");
    exit;
}

// Mendapatkan username operator dari cookie sesi
$username_op = $_COOKIE['session_op'];

?>
<?php
require_once '../koneksi.php';

try {
    // Mendapatkan data penjualan dari database
    $sql = "SELECT Penjualan.ID_Penjualan, Barang.Nama_Barang, Penjualan.jam, Penjualan.Jumlah, Penjualan.Jenis_Transaksi, 
            CASE WHEN Penjualan.Jenis_Transaksi = 'Baru' THEN Barang.Harga_Beli_Barang_Baru_Admin ELSE Barang.Harga_Isi_Ulang_Admin END AS Harga,
            (Penjualan.Jumlah * CASE WHEN Penjualan.Jenis_Transaksi = 'Baru' THEN Barang.Harga_Beli_Barang_Baru_Admin ELSE Barang.Harga_Isi_Ulang_Admin END) AS Total 
            FROM Penjualan
            INNER JOIN Barang ON Penjualan.ID_Barang = Barang.ID_Barang
            ORDER BY Penjualan.ID_Penjualan ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $data_penjualan = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Menghitung total pendapatan admin
    $total_pendapatan = 0;
    foreach ($data_penjualan as $penjualan) {
        $total_pendapatan += $penjualan['Total'];
    }
} catch (PDOException $e) {
    error_log($e->getMessage());
    die("Terjadi kesalahan pada database.");
}
?>





<!DOCTYPE html>
<html>
  <head>
          <title>Laporan Penjualan barang (Admin)</title>
      <?php include "../head.php";?>
  </head>
  <body>
    <div class="container mt-3 mb-3">
      <div class="row">
        <div class="col md-auto mt-3 mb-3">
<?php include "logo.php";?>          <div class="card mt-3 mb-3">
            <div style="background-color:rgba(116, 212, 66, 1);color:#fff;"class="card-header">
              <h5 class="card-title">Tabel data penjualan (Admin area)</h5>
            </div>
            <div class="card-body">
                

<!-- Tabel Data Penjualan -->
<div class="table table-responsive">
    <table class="table table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Waktu Penjualan</th>
                    <th>Jumlah Terjual</th>
                    <th>Jenis Transaksi</th>
                    <th>Harga (Admin)</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data_penjualan as $index => $penjualan) : ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo $penjualan['Nama_Barang']; ?></td>
                        <td><?php echo $penjualan['jam']; ?></td>
                        <td><?php echo $penjualan['Jumlah']; ?></td>
                        <td><?php echo $penjualan['Jenis_Transaksi']; ?></td>
                        <td>Rp. <?php echo number_format($penjualan['Harga'], 2); ?></td>
                        <td>Rp. <?php echo number_format($penjualan['Total'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
                        <tfoot>
                <tr>
                    <th colspan="6">Total Pendapatan (Operator)</th>
                    <th>Rp. <?php echo number_format($total_pendapatan, 2); ?></th>
                </tr>
            </tfoot>
</table>
</div>

        <div class="mb-3">
            <button class="btn btn-danger md-2 mt-2 mb-2" onclick="confirmDelete()">Hapus Data Penjualan</button>
              <button class="btn btn-primary md-2 mt-2 mb-2"onclick="convertToPDF()">Jadikan PDF</button>

  <script>
    function convertToPDF() {
      window.print();
    }
  </script>
  
        </div>
    <script>
        function confirmDelete() {
            if (confirm("Apakah Anda yakin ingin menghapus semua data penjualan hari ini?")) {
                // Redirect to delete script or perform deletion action
                window.location.href = "hapus-penjualan.php";
            }
        }
    </script>

            </div>
          </div>
          
          
          <!-- batas -->
        </div>
      </div>
    </div>
    </div>
      <?php include "../footer.php";?>
  </body>
</html>