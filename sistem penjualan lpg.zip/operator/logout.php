<?php
// Hapus cookie session_operator
setcookie('session_operator', '', time() - 3600, '/');

// Redirect kembali ke halaman login operator
header("Location: login-operator.php");
exit;
?>
